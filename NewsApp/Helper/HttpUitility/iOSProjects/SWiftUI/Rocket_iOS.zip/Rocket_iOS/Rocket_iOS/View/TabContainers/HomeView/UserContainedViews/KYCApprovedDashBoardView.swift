//
//  KYCApprovedDashBoardView.swift
//  Rocket_iOS
//
//  Created by Apple on 28/12/21.
//

import SwiftUI

struct KYCApprovedDashBoardView: View {
    var body: some View {
        VStack{
            KVCInitiatedDashBoardView()
//                .background(Color.red)
        }
    }
}

struct KYCApprovedDashBoardView_Previews: PreviewProvider {
    static var previews: some View {
        KYCApprovedDashBoardView()
    }
}
