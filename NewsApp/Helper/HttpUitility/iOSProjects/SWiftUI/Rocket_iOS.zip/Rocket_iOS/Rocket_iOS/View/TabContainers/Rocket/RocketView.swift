//
//  RocketView.swift
//  Rocket_iOS
//
//  Created by Apple on 21/12/21.
//

import SwiftUI

struct RocketView: View {
    var body: some View {
        VStack {
            Text("RocketView VIEW")
        } .navigationBarHidden(true)
    }
}

struct RocketView_Previews: PreviewProvider {
    static var previews: some View {
        RocketView()
    }
}
