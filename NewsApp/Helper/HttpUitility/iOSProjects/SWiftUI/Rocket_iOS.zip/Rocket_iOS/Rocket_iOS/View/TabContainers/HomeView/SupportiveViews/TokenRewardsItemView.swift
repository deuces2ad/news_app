//
//  TokenGatheringItemView.swift
//  Rocket_iOS
//
//  Created by Apple on 23/12/21.
//

import SwiftUI

struct TokenRewardsItemView: View {
    
    var text : String
    
    var body: some View {
        
        VStack {
            GeometryReader{ proxy in
                let size = proxy.size
                
                HStack{
                    HStack{
                        RocketInsideCircularStroke()
                        Text("0")
                            .font(Font.custom(AppThemeConfig.AvenirFont, size: 18))
                            .foregroundColor(AppThemeConfig.themeLightBrownColor)
                    }
                    
                    Text(text)
                        .font(Font.custom(AppThemeConfig.AvenirFont, size: 15))
                        .fixedSize()
                        .padding([.leading,],10)
                        .frame(maxWidth:.infinity,alignment: .leading)
                    
                        .zIndex(1)
                    
                    CustomButton(title: "Go", verticlePadding: 3, backgroundColor: AppThemeConfig.themeYellowColor) {
                        //
                    }
                    .frame(width: size.width * 0.14,height: 20)
                }
//                .padding()
            }
            .padding(.vertical,16)
//            .padding(.leading,20)
        }
    }
}

struct TokenGatheringItemView_Previews: PreviewProvider {
    static var previews: some View {
        TokenRewardsItemView(text: "cc")
            .previewLayout(.fixed(width: 400, height: 80))
    }
}
