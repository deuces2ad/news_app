//
//  LoginPageHeadingTitle.swift
//  Rocket_iOS
//
//  Created by Apple on 20/12/21.
//

import Foundation


enum LoginPageHeadingTitle :String{
    case Login = "Login"
    case Signup = "Signup"
    case TheLastStep = "The Last Step!"
}
