//
//  KVCInitiatedDashBoardView.swift
//  Rocket_iOS
//
//  Created by Apple on 28/12/21.
//

import SwiftUI


struct KVCInitiatedDashBoardView: View {
    
    let TAG = "KVCInitiatedDashBoardView"
    
    var imageSize : CGFloat{
        return CGFloat(UIDevice.isIPad ? 0.36 : UIDevice.hasNotch ? 0.38 : 0.40)
    }
    
    var body: some View {
        
        GeometryReader { _ in
            
            AppThemeConfig.themeLightYellowColor
                .frame(width: getRect().width, height: getRect().height * imageSize)
                .edgesIgnoringSafeArea(.top)
                .overlay(
                    GeometryReader { proxy in
                        let size = proxy.size
                        BackgroundImage(imageName: "homeBg", contentMode: .fit)
                            .frame(width: size.width, height: size.height)
                        
                    })
            VStack(alignment: .leading){
                
                LoginedUserInfoTopView(userProfilePicture: "userImage",userName: "Charli Jane")
                
                VStack(alignment: .leading, spacing: 15){
                    Text("Total Portfolio")
                        .foregroundColor(AppThemeConfig.themeLightBrownColor)
                        .font(Font.custom(AppThemeConfig.AvenirFont, size: 16))
                    
                    Text("Rp 0")
                        .font(Font.custom(AppThemeConfig.AvenirFont, size: 16).weight(.heavy))
                        .foregroundColor(AppThemeConfig.themeLightBrownColor)
                    
                }//VSTACK
                .padding(.top)
                
                VStack(alignment: .leading, spacing: 2){
                    
                    Text("Yield")
                        .foregroundColor(AppThemeConfig.themeLightBrownColor)
                        .font(Font.custom(AppThemeConfig.AvenirFont, size: 16))
                        .padding(.top,2)
                    
                    
                    
                    
                    HStack{
                        Image("arrowtriangle.up.fill")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 16, height: 14)
                        
                        Text("Rp 0 (0%)")
                            .foregroundColor(AppThemeConfig.themeGreenColor)
                            .font(Font.custom(AppThemeConfig.AvenirFont, size: 16))
                            .padding(.horizontal,5)
                        
                        Spacer()
                        
                        CustomButton(title: "Portfolio", verticlePadding: 13, backgroundColor: AppThemeConfig.themeYellowColor) {
                            Log.echo(key: TAG, text: "Portfolio button tapped")
                        }
                        .frame(width:getRect().width * 0.30)
                        
                    }
                    .padding(.leading,5)
                    .padding(.bottom)
                }
   
            }
            .padding()
            
        }
    }
}

struct KVCInitiatedDashBoardView_Previews: PreviewProvider {
    static var previews: some View {
        KVCInitiatedDashBoardView()
            .previewLayout(.sizeThatFits)
    }
}
