//
//  Rocket_iOSApp.swift
//  Rocket_iOS
//
//  Created by Apple on 14/12/21.
//

//import SwiftUI
//
//@available(iOS 14.0, *)
//@main
//struct Rocket_iOSApp: App {
//    var body: some Scene {
//        WindowGroup {
//            ContentView()
//        }
//    }
//}
