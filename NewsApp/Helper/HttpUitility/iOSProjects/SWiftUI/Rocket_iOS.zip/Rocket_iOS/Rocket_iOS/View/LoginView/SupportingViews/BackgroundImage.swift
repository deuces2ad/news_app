//
//  BackgroundImage.swift
//  Rocket_iOS
//
//  Created by Apple on 17/12/21.
//

import SwiftUI

struct BackgroundImage: View {
    
     // MARK: - Image Size
    var imageSize : CGFloat{
        return CGFloat(UIDevice.isIPad ? 600 : 350)
    }
    var imageName : String
    var contentMode : ContentMode
    
     // MARK: - BODY
    
    var body: some View {

            ZStack{
                Image(imageName)
                    .resizable()
                    .aspectRatio(contentMode: contentMode)
                    .frame(height: imageSize)
                .frame(maxWidth:.infinity,maxHeight: .infinity)
            }
            
    }
}

struct BackgroundImage_Previews: PreviewProvider {
    static var previews: some View {
        Group{
            BackgroundImage(imageName: "homeBg", contentMode: .fill)
                .previewDevice("iPhone 8")
                .previewLayout(.fixed(width: 400, height: 400))
            BackgroundImage(imageName: "homeBg", contentMode: .fill)
                .previewDevice("iPhone 13")
                .previewLayout(.fixed(width: 400, height: 400))
            BackgroundImage(imageName: "homeBg", contentMode: .fill)
                .previewDevice("iPad mini")
        }
      
    }
}
