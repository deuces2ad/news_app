//
//  HttpUtility.h
//  HttpUtility
//
//  Created by CodeCat15 on 5/17/20.
//  Copyright © 2020 CodeCat15. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for HttpUtility.
FOUNDATION_EXPORT double HttpUtilityVersionNumber;

//! Project version string for HttpUtility.
FOUNDATION_EXPORT const unsigned char HttpUtilityVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HttpUtility/PublicHeader.h>


