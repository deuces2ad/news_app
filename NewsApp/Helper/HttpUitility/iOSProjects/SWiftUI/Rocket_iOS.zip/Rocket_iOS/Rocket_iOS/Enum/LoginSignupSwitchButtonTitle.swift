//
//  LoginSignupSwitchButtonTitle.swift
//  Rocket_iOS
//
//  Created by Apple on 20/12/21.
//

import Foundation

enum LoginSignupSwitchButtonTitle : String {
    
case LoginBtnAction = "Login"
case SignupBtnAction = "Signup"
case LastStepAction = "Previous"
    
}
