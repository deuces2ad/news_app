//
//  DevFlag.swift
//  Health Tracker
//
//  Created by Abhishek Dhiman on 13/12/21.
//  Copyright © 2021 Abhishek Dhiman. All rights reserved.
//

import Foundation

class DevFlag : NSObject{
    
    @objc static let key = "abhishekD"
    @objc static let showAll = true
    @objc static let debug = true
}

