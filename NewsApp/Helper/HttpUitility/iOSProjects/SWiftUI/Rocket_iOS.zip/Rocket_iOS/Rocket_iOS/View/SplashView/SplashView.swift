//
//  SplashView.swift
//  Rocket_iOS
//
//  Created by Apple on 18/12/21.
//

import SwiftUI

struct SplashView: View {
    
     // MARK: - PROPERTIES
    
    @State private var showOnboardView : Bool = false
    
     // MARK: - BODY
    
    var body: some View {
    
        ZStack{
           Text("MY SPLSH VIEW")
            if showOnboardView{
                    AppRootView()
                    .transition(.opacity)
            }
        }//ZSTACK
        .background(AppThemeConfig.themeYellowColor)
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                showOnboardView = true
            }
        }
    }
}

struct SplashView_Previews: PreviewProvider {
    static var previews: some View {
        SplashView()
    }
}
