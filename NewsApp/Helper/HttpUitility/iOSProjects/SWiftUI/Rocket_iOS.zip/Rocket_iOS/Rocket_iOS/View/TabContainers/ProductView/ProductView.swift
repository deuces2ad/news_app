//
//  ProductView.swift
//  Rocket_iOS
//
//  Created by Apple on 21/12/21.
//

import SwiftUI

struct ProductView: View {
    var body: some View {
        VStack {
            Text("PRODUCT VIEW")
        } .navigationBarHidden(true)
    }
}

struct ProductView_Previews: PreviewProvider {
    static var previews: some View {
        ProductView()
    }
}
