//
//  LoginView.swift
//  Rocket_iOS
//
//  Created by Apple on 16/12/21.
//

import SwiftUI
import Combine

struct LoginView: View {
    
    // MARK: - PROPRTIES
    
    private let TAG = "LoginView"
    @State private var keyboardHeight: CGFloat = 0
    
  
    var imageSize : CGFloat{
        return CGFloat(UIDevice.isIPad ? 630 : 300)
    }
    
    var conatinerSize : CGFloat{
        return CGFloat(UIDevice.isIPad ? 0.55 : 0.65)
    }
    // MARK: - BODY
    
    var body: some View {
        
        GeometryReader { proxy in
            let size = proxy.size
            ZStack{
                VStack(alignment: .leading, spacing: 5){
                    AppThemeConfig.themeDarkBrown
                        .frame(maxWidth: .infinity)
                        .frame(width: getRect().width, height: imageSize)
                    
                        .overlay(
                            GeometryReader { proxy in
                                let size = proxy.size
                                BackgroundImage(imageName: "ic_login_cloud", contentMode: .fill)
                                    .frame(width: size.width, height: size.height)
                                
                            })
                    
                    Spacer()
                }
                .overlay(
                    VStack{
                        VStack{
                            Spacer()
                            LoginAndSignupFields()
                                .frame(height:getRect().height * conatinerSize)
                                .padding([.leading,.trailing,.top],10)
                                .padding([.bottom],0)
                                .background(
                                    Color.white
                                        .clipShape(RoundedCorner(radius: 25, corners: [.topLeft,.topRight]))
                                )
                        }
                    }
                )
                .edgesIgnoringSafeArea(.all)
                .navigationBarHidden(true)
                .embedInNavigationView()
                .onTapGesture {
                    UIApplication.shared.endEditing()
                }
                .navigationViewStyle(StackNavigationViewStyle())
            }
        }
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        
        Group{
            LoginView()
                .previewDevice("iPhone 8")
                .background(Color.red)
            LoginView()
                .background(Color.red)
                .previewDevice("iPhone 13")
            LoginView()
                .background(Color.red)
                .previewDevice("iPad mini (6th generation)")

        }

    }
}


