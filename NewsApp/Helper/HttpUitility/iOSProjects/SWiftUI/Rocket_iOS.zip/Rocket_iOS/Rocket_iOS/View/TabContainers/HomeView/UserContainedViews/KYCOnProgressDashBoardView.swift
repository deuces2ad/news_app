//
//  KYCOnProgressDashBoardView.swift
//  Rocket_iOS
//
//  Created by Apple on 28/12/21.
//

import SwiftUI

struct KYCOnProgressDashBoardView: View {
    
     // MARK: - PROPERTIES
    
    
    var body: some View {
        VStack{
            KVCInitiatedDashBoardView()
                .overlay(
                    RoundedRectAngleContainerView{
                       LoginAndSignupFields()
                        
                    }

                )
        }
    }
}

struct KYCOnProgressDashBoardView_Previews: PreviewProvider {
    static var previews: some View {
        KYCOnProgressDashBoardView()
    }
}

struct RoundedRectAngleContainerView<Content: View>: View {
    
    let content: Content
    
    init(@ViewBuilder content: () -> Content) {
            self.content = content()
        }
    
    var contanerSize : CGFloat {
        return UIDevice.isIPad ? 0.45 : 0.60
    }
    
    var body: some View {
        VStack(alignment: .leading){
            ZStack{
                Rectangle()
                    .foregroundColor(.white)
                    .clipShape(RoundedCorner(radius: 35, corners: [.topLeft,.topRight]))
                
                content
            }
        }//ZSTACK
        .frame(width: getRect().width, height: getRect().height * contanerSize)
        .background(AppThemeConfig.themeLightYellowColor)
        .frame(maxWidth:.infinity,maxHeight: .infinity,alignment: .bottom)
    }
}
