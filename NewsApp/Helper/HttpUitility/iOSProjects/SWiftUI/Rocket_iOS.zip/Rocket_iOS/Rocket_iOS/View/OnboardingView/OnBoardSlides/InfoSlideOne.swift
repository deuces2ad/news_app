//
//  InfoSlideOne.swift
//  Rocket_iOS
//
//  Created by Apple on 15/12/21.
//

import SwiftUI

struct InfoSlideOne: View {

 // MARK: - BODY
    var body: some View {
        VStack{
            PlanetTwoImage()
            Spacer()
            PlanetOneImage()
            Spacer()
            InfoTextForSlideOne()
            Spacer()
        }//VSTACK
    }
}

struct InfoSlideOne_Previews: PreviewProvider {
    static var previews: some View {
//        Group{
            InfoSlideOne()
                .previewDevice("iPhone 8")
//            InfoSlideOne()
//                .previewDevice("iPhone 13")
//        }
    }
}





