//
//  TokenRewardsDistribution.swift
//  Rocket_iOS
//
//  Created by Apple on 23/12/21.
//

import SwiftUI

struct TokenRewardsDistribution: View {
    
    let tokenRewardsDiscrptionTxts : [String] = ["Lengkapi Identitasmu",
                                                 "Verifikasi Email",
                                                 "KYC",
                                                 "Bangun Impian"]
    
    var body: some View {
        VStack(alignment: .trailing, spacing: 0) {
            Text("How To Get Tokens")
                .font(Font.custom(AppThemeConfig.AvenirFont, size: 21))
                .foregroundColor(AppThemeConfig.themeLightBrownColor)
                .frame(maxWidth:.infinity,alignment: .leading)

            
            VStack{
                ForEach(tokenRewardsDiscrptionTxts.indices , id : \.self){ item in
                    TokenRewardsItemView(text: tokenRewardsDiscrptionTxts[item])
                
                }
            }
        }
        .padding(.horizontal,20)
    }
}

struct TokenRewardsDistribution_Previews: PreviewProvider {
    static var previews: some View {
        TokenRewardsDistribution()
    }
}
