//
//  AppInfoConfig.swift
//  Health Tracker
//
//  Created by Abhishek Dhiman on 13/12/21.
//  Copyright © 2021 Abhishek Dhiman. All rights reserved.
//

import Foundation

class AppInfoConfig {
    static var appName = "Rocket"
    static var deviceType = "iOS"
    static var appversion = "1.0"
    //TODO:- Change the version
}
