//
//  HelpView.swift
//  Rocket_iOS
//
//  Created by Apple on 21/12/21.
//

import SwiftUI

struct HelpView: View {
    var body: some View {
        VStack {
            Text("Help View")
        } .navigationBarHidden(true)
    }
}

struct HelpView_Previews: PreviewProvider {
    static var previews: some View {
        HelpView()
    }
}
